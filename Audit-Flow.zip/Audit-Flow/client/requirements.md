## Packages
date-fns | For formatting dates nicely (e.g., "MMM dd, yyyy")

## Notes
- Using Google Fonts: 'Inter' (sans) and 'Outfit' (display)
- File uploads use the pre-installed @uppy dependencies via ObjectUploader
- Auth flow: Redirects to /profile-setup if profile is missing
